import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FoodserviceService } from '../foodservice.service';

@Component({
  selector: 'app-pastadetail',
  templateUrl: './pastadetail.page.html',
  styleUrls: ['./pastadetail.page.scss'],
})
export class PastadetailPage implements OnInit {
  
  pastas: any = {};  
  index = 0;

  constructor(private route: ActivatedRoute, private foodService: FoodserviceService) {}

  ngOnInit() {
    
    this.route.params.subscribe(params => {
      const id = params["index"];
      
      this.foodService.pastaDetail(id).subscribe(
        (data) => {
          console.log(data); 
          this.pastas = data;
        },
        (error) => {
          console.error('Error fetching pasta details:', error);
        }
      );
    });
  }
}
